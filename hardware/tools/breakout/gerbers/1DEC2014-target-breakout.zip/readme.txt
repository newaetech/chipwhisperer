PCB Specs:

5.8 cm x 3.8 cm
FR4 1.6mm
GREEN Soldermask with WHITE silkscreen

------------------------------------------------------
File Type:

.TOPSILKSCREEN.GTO    : Top Silkscreen Layer (WHITE)
.TOPMASK.GTS          : Top Solder-Mask Layer (GREEN)
.TOPCOPPER.GTL        : Top Copper Layer

.BOTTOMCOPPER.GBL     : Bottom Copper Layer
.BOTTOMMASK.GBS       : Bottom Solder-Mask Layer (GREEN)
.BOTTOMSILKSCREEN.BTO : Bottoom Silkscreen Layer (WHITE)

.NCDILL.DRD           : NC-Drill File
.MILL.GML             : Outer Mill Layer

.TOPSTENCIL.GTP       : Used to Generate Stencil for Soldering (IGNORED FOR PCB MANUFACTURING)
.BOTSTENCIL.GBP       : Used to Generate Stencil for Soldering (IGNORED FOR PCB MANUFACTURING)

-------------------------------------------------------


All sizes after plating.