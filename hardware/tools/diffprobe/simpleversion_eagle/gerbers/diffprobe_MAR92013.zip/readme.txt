
PCB Information:
	Material: FR-4
	Copper Weight: 1.0 Oz
	Finish: RoHS Compliant
	Soldermask: Black
	Silkscreen: White
	Thickness: 0.062" (

File List:
	.BOTTOMCOPPER.GBR: 		 Bottom Layer - Copper, 1 Oz
	.BOTTOMMASK.GBR:   		 Bottom Layer - Soldermask (Color = BLACK)
	.BOTTOMSILKSCREEN.GBR:   Bottom Layer - Silkscreen (Color = White)
	.TOPCOPPER.GBR:    		 Top Layer - Copper, 1 Oz
	.TOPMASK.GBR:      		 Top Layer - Soldermask (Color = BLACK)
	.TOPSILKSCREEN.GBR:		 Top Layer - Silkscreen (Color = White)
	.MILL.GBR:         		 Board Outline
	.NCDRILL:          		 NC Drill File

