PCB Specs:

10.0 cm x 15.5 cm
FR4 1.6mm
RED Soldermask with WHITE silkscreen
Line Width & Space > 0.17 mm
Finish: Immersion Gold

------------------------------------------------------

File Type:

.TOPSILKSCREEN.GTO    : Top Silkscreen Layer (WHITE)
.TOPMASK.GTS          : Top Solder-Mask Layer (RED)
.TOPCOPPER.GTL        : Top Copper Layer

.BOTTOMCOPPER.GBL     : Bottom Copper Layer
.BOTTOMMASK.GBS       : Bottom Solder-Mask Layer (RED)
.BOTTOMSILKSCREEN.BGO : Bottom Silkscreen Layer (WHITE)

.NCDILL.DRD           : NC-Drill File
.MILL.GML             : Outer Mill Layer

.TOPSTENCIL.GTP       : Top Paste Layer (e.g. for stencil)
.BOTSTENCIL.GBP       : Bottom Paste Layer (e.g. for stencil)

-------------------------------------------------------

All sizes after plating