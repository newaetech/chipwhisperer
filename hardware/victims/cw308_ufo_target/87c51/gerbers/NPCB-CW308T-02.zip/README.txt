2-Layer PCB

Soldermask: Blue
Silkscreen: White

Finish: HASL

55.5mm x 84.5mm

Board Files:

 .GTO - Top Silkscreen
 .GTS - Top Soldermask
 .GTL - Top Copper
 .GBL - Bottom Copper
 .GBS - Bottom Soldermask
 .GBO - Bottom Silkscreen
 .GM3 - Board Outline
 .NCDRILL - Drill File


Other Files:

 .GTP - Top Paste (for stencil)
 .GBP - Bottom Paste (for stencil)