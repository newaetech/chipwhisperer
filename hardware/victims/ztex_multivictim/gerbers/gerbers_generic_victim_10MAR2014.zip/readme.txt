PCB Specs:

8.476 cm x 12.317 cm
FR4 1.6mm
BLACK Soldermask with WHITE silkscreen
Line Width & Space > 0.2mm

------------------------------------------------------
File Type:

.TOPSILKSCREEN.GTO    : Top Silkscreen Layer (WHITE)
.TOPMASK.GTS          : Top Solder-Mask Layer (BLACK)
.TOPCOPPER.GTL        : Top Copper Layer

.BOTTOMCOPPER.GBL     : Bottom Copper Layer
.BOTTOMMASK.GBS       : Bottom Solder-Mask Layer (BLACK)
.BOTTOMSILKSCREEN.BGO : Bottom Silkscreen Layer (WHITE)

.NCDILL.DRD           : NC-Drill File
.MILL.GML             : Outer Mill Layer

.TOPSTENCIL.GTP       : Top Paste Layer (e.g. for stencil)
.BOTSTENCIL.GBP       : Bottom Paste Layer (e.g. for stencil)

-------------------------------------------------------

All sizes after plating.