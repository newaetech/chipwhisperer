Shipping Address:

Colin O'Flynn
Electrical & Computer Engineering Department
Dalhousie University
1360 Barrington Street, C367
Halifax, NS
B3J 1Z1

Phone 1: 902 440 1458
Phone 2: 902 494 3106

coflynn@newae.com

--------------------------------------------------------

Academic Order, was told to include this note from Laura:

Hi Colin -

I am willing to offer up to $500 in sponsorship exclusive of shipping to you for 2013.
The sponsorship is for product we manufacture in house so that would be BASIC or PLUS orders.
When you submit your designs just include a copy of this email with the order so my team sees it.
The boards will have our logo on them it that is okay with you.

Best Regards,

Laura

---------------------------------------------------------

All sizes after plating, should be in 'free' tooling