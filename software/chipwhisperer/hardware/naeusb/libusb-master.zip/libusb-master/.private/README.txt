This directory contains private internal scripts used by the libusb
project maintainers.

These scripts are not intended for general usage and will not be
exported when producing release archives.
