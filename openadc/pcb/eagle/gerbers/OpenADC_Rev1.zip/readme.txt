
PCB Information:
	Material: FR-4
	Copper Weight: 1.0 Oz
	Finish: RoHS Compliant
	Soldermask: Red
	Silkscreen: White
	Thickness: 0.062" (NB: depends on only SMA EDGE Connectors specified in BOM)

File List:
	.BOTTOMCOPPER.GBR: Bottom Layer - Copper, 1 Oz
	.BOTTOMMASK.GBR:   Bottom Layer - Soldermask (Color = Red)
	.BOTTOMSILK.GBR:   Bottom Layer - Silkscreen (Color = White)
	.TOPCOPPER.GBR:    Top Layer - Copper, 1 Oz
	.TOPMASK.GBR:      Top Layer - Soldermask (Color = Red)
	.TOPSILK.GBR:      Top Layer - Silkscreen (Color = White)
	.MILL.GBR:         Board Outline
	.NCDRILL:          NC Drill File
	.STENCIL.GBR:      File to generate SMD Solder Paste Stencil

File Information:
	Device            : Excellon drill station
	 OffsetX           : 0inch
	 OffsetY           : 0inch
	 Data Mode         : Absolute
	 Units             : 1/10000 Inch

	Drills used:

	 Code  Size       used

	 T01   0.0170inch    81
	 T02   0.0250inch     2
	 T03   0.0300inch     1
	 T04   0.0354inch     1
	 T05   0.0400inch    35
	 T06   0.0590inch     1
	 T07   0.0700inch     4
	 T08   0.1102inch     1

	Total number of drills: 126

	Device            : Gerber RS-274-X photoplotter, coordinate format 2.4 inch
	 OffsetX           : 0inch
	 OffsetY           : 0inch
	 Coordinate Format : 2.4
	 Coordinate Units  : Inch
	 Data Mode         : Absolute
	 Zero Suppression  : None
	 End Of Block      : *
