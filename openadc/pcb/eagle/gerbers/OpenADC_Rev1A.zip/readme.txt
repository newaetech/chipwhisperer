
PCB Information:
	Material: FR-4
	Copper Weight: 1.0 Oz
	Finish: RoHS Compliant
	Soldermask: Red
	Silkscreen: White
	Thickness: 0.062" (NB: depends on only SMA EDGE Connectors specified in BOM)

File List:
	.BOTTOMCOPPER.GBR: Bottom Layer - Copper, 1 Oz
	.BOTTOMMASK.GBR:   Bottom Layer - Soldermask (Color = Red)
	.BOTTOMSILK.GBR:   Bottom Layer - Silkscreen (Color = White)
	.TOPCOPPER.GBR:    Top Layer - Copper, 1 Oz
	.TOPMASK.GBR:      Top Layer - Soldermask (Color = Red)
	.TOPSILK.GBR:      Top Layer - Silkscreen (Color = White)
	.MILL.GBR:         Board Outline
	.NCDRILL:          NC Drill File
	.STENCIL.GBR:      File to generate SMD Solder Paste Stencil

File Information:
	Device            : Excellon drill station
	 OffsetX           : 0inch
	 OffsetY           : 0inch
	 Data Mode         : Absolute
	 Units             : 1/10000 Inch

	Device            : Gerber RS-274-X photoplotter, coordinate format 2.4 inch
	 OffsetX           : 0inch
	 OffsetY           : 0inch
	 Coordinate Format : 2.4
	 Coordinate Units  : Inch
	 Data Mode         : Absolute
	 Zero Suppression  : None
	 End Of Block      : *
